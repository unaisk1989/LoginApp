//Configuration file for storing connection. Can store other configuration
//properties as well

module.exports = {
    db_url: 'mongodb+srv://admin:admin%40123@cluster0-cqzu3.mongodb.net/Test?retryWrites=true&w=majority',
    secret : "itsunaiskhere" //secret for JSON web token
}